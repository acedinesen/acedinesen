First create a library by using the command fsharpc -a readNWrite.fs
This creates a .dll file which you can combine with the .fsx files with the command
fsharpc -r readNWrite.dll "file".fsx

Now you can run the code with mono "file".exe

An example of running it:

The file test.txt contents is "test1", and the file test2.txt contents is "test2"

When you run the Cat file it will return test1 test2 
When you run the Tac file it will return 2tset 1tset


