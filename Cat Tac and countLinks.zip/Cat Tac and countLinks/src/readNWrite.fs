module readNWrite
open System.IO

// 9g0

/// <summary> A function that reads a string <summary>
/// <param name = "txt"> String <param>
/// <param name = "read"> Reads the string <param>
/// <returns> Returns the contents of the string <returns>

let rec run (txt:string) (read:System.IO.StreamReader) =
    if read.EndOfStream then
        txt
    else 
        let string:string = read.ReadLine()
        run (txt + string) read

/// <summary> A function that does a check to see if the chosen file exists <summary>
/// <param name = "filename"> Name of the chosen file <param>
/// <param name = "r"> Reads the contents of the file <param>
/// <returns> When a file is given it returns the contents of the file if it exists, otherwise it returns None if the file is nonexsistent. <returns>

let readFile (filename:string) : string option =
    if System.IO.File.Exists filename then 
        let (r:System.IO.StreamReader) = System.IO.File.OpenText filename
        Some (run "" r)
    else None 



//9g1

/// <summary> Cat takes a list of given file names and uses the ReadFile to compile it into a string and then recite it in the correct order. <summary>
/// <param name = "filenames"> Is the list of filenames. <param>
/// <returns> The files in the correct order. <returns>

let Cat (filenames:string List) : string option =
    let ls = List.map readFile filenames
    try
        (Some (List.choose (fun i-> i) ls |> String.concat "\n"))
    with
         _ -> None



//9g2
/// <summary> Tac takes a list of given file names and uses the ReadFile to compile it into a string but returnes it in the opposite order.<summary>
/// <param name = "filenames"> Is the list of filenames. <param>
/// <returns> The files in backwards order. <returns>

let Tac (filenames:string list) : string option =
    match Cat filenames with 
     | None -> None
     | Some string -> Some (System.String.Concat(Array.ofList(List.rev(List.ofSeq(string)))))

